# Change history

## 1.0.6, 2026-10-21

- Advance the patch version for a new Zen Cart plugin repository upload.
- Retain the duplicate filename constant warning fix introduced in 1.0.5.
- Preserve official plugin ID 2458 and validate it during release checks.
- Build the distribution with one current version directory and one manifest.
- Existing rules, owned Specials, quantity tracking, and promotion behavior are unchanged.

## 1.0.5, 2026-09-15

- Guarded the root filename constant so the admin bootstrap can load it after the admin fallback without producing a duplicate constant warning.
- Added a package check that loads the filename definitions twice to prevent this regression.

## 1.0.4, 2026-09-10

- Added an optional combined quantity sold limit for each rule.
- Added completed order quantity tracking across every product owned by the rule.
- Added automatic Special deactivation when the quantity limit is reached.
- Added quantity sold, remaining quantity, completion status, and counter reset controls.
- Documented that expiration date and quantity limit use whichever condition occurs first.

## 1.0.3, 2026-09-10

- Removed the collapsed rule form border that could appear as brackets over the page and Save rule button.
- Added plain instructions for every rule field and clarified how combined filters, price limits, attribute products, pricing methods, dates, and rounding work.

## 1.0.2, 2026-09-10

- Corrected double escaping in administration links and form targets so action parameters reach Zen Cart's `cmd` router.
- Restored Create rule, edit, preview, apply, save, cancel, and delete navigation.

## 1.0.1, 2026-09-10

- Restored the complete Zen Cart administration document wrapper so administration stylesheets and scripts load normally.
- Changed included attribute priced products to use Zen Cart's native base price calculation for price filters and calculated discounts.

## 1.0.0, 2026-09-10

- Added reusable Specials rules.
- Added manufacturer, category, descendant category, price, stock, model, date, featured, and active product filters.
- Added an option to exclude products priced by attributes.
- Added percentage, amount, and set price methods.
- Added optional two decimal rounding for calculated discounts.
- Added preview, conflict reporting, native Specials creation, rule ownership tracking, and safe cleanup.
- Added Plugin Manager installation, runtime menu repair, documentation, and PHP lint workflow.
